import java.util.ArrayList;
import java.util.List;

/**
 * Analisador sintatico (parser descendente recursivo).
 *
 * Gramatica expandida:
 *   Programa        -> ( Funcao | Declaracao | Bloco )*
 *   Funcao          -> [TIPO] [NOMEVARIAVEL] [ABRE_PARENTESES] [FECHA_PARENTESES] Bloco
 *   Bloco           -> [ABRE_CHAVES] Comando* [FECHA_CHAVES]
 *   Comando         -> Declaracao | Bloco
 *   Declaracao      -> [TIPO] [NOMEVARIAVEL] Inicializacao DeclaraMultiplo* [PONTO_VIRGULA]
 *   Inicializacao   -> [ATRIBUICAO] [VALOR] | epsilon
 *   DeclaraMultiplo -> [VIRGULA] [NOMEVARIAVEL] Inicializacao
 *   [VALOR]         -> [INTEIRO] | [FRACIONARIO] | [NOMEVARIAVEL]
 */
public class AnalisadorSintatico {

    public static class ErroSintatico extends Exception {
        public ErroSintatico(String mensagem) {
            super(mensagem);
        }
    }

    public static class NoArvore {
        private final String rotulo;
        private final ReconhecedorAFD.EntradaTabelaSimbolos token;
        private final List<NoArvore> filhos = new ArrayList<>();

        public NoArvore(String rotulo) {
            this.rotulo = rotulo;
            this.token = null;
        }

        public NoArvore(String rotulo, ReconhecedorAFD.EntradaTabelaSimbolos token) {
            this.rotulo = rotulo;
            this.token = token;
        }

        public void addFilho(NoArvore filho) {
            filhos.add(filho);
        }

        public List<NoArvore> getFilhos() {
            return filhos;
        }

        public String getRotulo() {
            return rotulo;
        }

        private String descricaoLinha() {
            if (token != null) {
                return rotulo + " -> \"" + token.getToken() + "\" (linha " + token.getLinha()
                        + ", coluna " + token.getColuna() + ")";
            }
            return rotulo;
        }

        public void imprimir() {
            imprimir("", true);
        }

        private void imprimir(String prefixo, boolean ultimo) {
            System.out.println(prefixo + (ultimo ? "`-- " : "|-- ") + descricaoLinha());
            String novoPrefixo = prefixo + (ultimo ? "    " : "|   ");
            for (int i = 0; i < filhos.size(); i++) {
                filhos.get(i).imprimir(novoPrefixo, i == filhos.size() - 1);
            }
        }
    }

    private static final java.util.Set<String> TIPOS_VALIDOS = java.util.Set.of(
            "PR_INT", "PR_CHAR", "PR_FLOAT", "PR_DOUBLE", "PR_VOID", "PR_BOOLEAN");

    private static final java.util.Set<String> VALORES_VALIDOS = java.util.Set.of(
            "INTEIRO", "FRACIONARIO", "NOMEVARIAVEL");

    private final List<ReconhecedorAFD.EntradaTabelaSimbolos> tokens;
    private int posicao;

    public AnalisadorSintatico(List<ReconhecedorAFD.EntradaTabelaSimbolos> tokens) {
        this.tokens = tokens;
        this.posicao = 0;
    }

    private ReconhecedorAFD.EntradaTabelaSimbolos atual() {
        return posicao < tokens.size() ? tokens.get(posicao) : null;
    }

    private ReconhecedorAFD.EntradaTabelaSimbolos espiar(int offset) {
        int idx = posicao + offset;
        return idx < tokens.size() ? tokens.get(idx) : null;
    }

    private NoArvore consumir(String tipoEsperado, String rotuloNo) throws ErroSintatico {
        ReconhecedorAFD.EntradaTabelaSimbolos t = atual();
        if (t == null) {
            throw new ErroSintatico("Fim inesperado da entrada; esperado token do tipo " + tipoEsperado + ".");
        }
        if (!t.getTipo().equals(tipoEsperado)) {
            throw new ErroSintatico(descreverErro(t, "esperado " + tipoEsperado));
        }
        posicao++;
        return new NoArvore(rotuloNo, t);
    }

    private boolean tipoAtualEh(String tipo) {
        ReconhecedorAFD.EntradaTabelaSimbolos t = atual();
        return t != null && t.getTipo().equals(tipo);
    }

    private String descreverErro(ReconhecedorAFD.EntradaTabelaSimbolos t, String detalhe) {
        return "Erro sintatico: token \"" + t.getToken() + "\" (tipo " + t.getTipo()
                + ") na linha " + t.getLinha() + ", coluna " + t.getColuna() + " - " + detalhe + ".";
    }

    /**
     * Ponto de entrada do programa.
     */
    public NoArvore parsePrograma() throws ErroSintatico {
        NoArvore noPrograma = new NoArvore("Programa");
        while (atual() != null) {
            noPrograma.addFilho(parseElemento());
        }
        return noPrograma;
    }

    /**
     * Decide se a regra sera uma Funcao, Declaracao ou Bloco avulso.
     */
    private NoArvore parseElemento() throws ErroSintatico {
        if (tipoAtualEh("ABRE_CHAVES")) {
            return parseBloco();
        }

        ReconhecedorAFD.EntradaTabelaSimbolos tokTipo = atual();
        if (tokTipo != null && TIPOS_VALIDOS.contains(tokTipo.getTipo())) {
            ReconhecedorAFD.EntradaTabelaSimbolos proximo = espiar(1);
            ReconhecedorAFD.EntradaTabelaSimbolos aposNome = espiar(2);

            // Se for [TIPO] [NOMEVARIAVEL] "(", e uma definicao de funcao
            if (proximo != null && "NOMEVARIAVEL".equals(proximo.getTipo())
                    && aposNome != null && "ABRE_PARENTESES".equals(aposNome.getTipo())) {
                return parseFuncao();
            }
            return parseDeclaracao();
        }

        ReconhecedorAFD.EntradaTabelaSimbolos t = atual();
        throw new ErroSintatico(descreverErro(t, "esperado declaracao, funcao ou bloco"));
    }

    /**
     * Funcao -> [TIPO] [NOMEVARIAVEL] "(" ")" Bloco
     */
    public NoArvore parseFuncao() throws ErroSintatico {
        NoArvore noFuncao = new NoArvore("Funcao");

        ReconhecedorAFD.EntradaTabelaSimbolos tipoTok = atual();
        posicao++;
        noFuncao.addFilho(new NoArvore("[TIPO]", tipoTok));

        noFuncao.addFilho(consumir("NOMEVARIAVEL", "[NOMEVARIAVEL]"));
        noFuncao.addFilho(consumir("ABRE_PARENTESES", "[ABRE_PARENTESES]"));
        noFuncao.addFilho(consumir("FECHA_PARENTESES", "[FECHA_PARENTESES]"));
        noFuncao.addFilho(parseBloco());

        return noFuncao;
    }

    /**
     * Bloco -> "{" Comando* "}"
     */
    public NoArvore parseBloco() throws ErroSintatico {
        NoArvore noBloco = new NoArvore("Bloco");
        noBloco.addFilho(consumir("ABRE_CHAVES", "[ABRE_CHAVES]"));

        while (atual() != null && !tipoAtualEh("FECHA_CHAVES")) {
            noBloco.addFilho(parseElemento());
        }

        noBloco.addFilho(consumir("FECHA_CHAVES", "[FECHA_CHAVES]"));
        return noBloco;
    }

    /**
     * Declaracao -> [TIPO] [NOMEVARIAVEL] Inicializacao DeclaraMultiplo* ";"
     */
    public NoArvore parseDeclaracao() throws ErroSintatico {
        NoArvore noDeclara = new NoArvore("Declara");

        ReconhecedorAFD.EntradaTabelaSimbolos tipoTok = atual();
        if (tipoTok == null || !TIPOS_VALIDOS.contains(tipoTok.getTipo())) {
            if (tipoTok == null) {
                throw new ErroSintatico("Fim inesperado da entrada; esperado tipo primitivo.");
            }
            throw new ErroSintatico(descreverErro(tipoTok, "esperado tipo primitivo"));
        }
        posicao++;
        noDeclara.addFilho(new NoArvore("[TIPO]", tipoTok));

        noDeclara.addFilho(consumir("NOMEVARIAVEL", "[NOMEVARIAVEL]"));
        noDeclara.addFilho(parseInicializacao());

        while (tipoAtualEh("VIRGULA")) {
            NoArvore noMultiplo = new NoArvore("DeclaraMultiplo");
            posicao++; // consome VIRGULA
            noMultiplo.addFilho(consumir("NOMEVARIAVEL", "[NOMEVARIAVEL]"));
            noMultiplo.addFilho(parseInicializacao());
            noDeclara.addFilho(noMultiplo);
        }

        noDeclara.addFilho(consumir("PONTO_VIRGULA", "[PV]"));
        return noDeclara;
    }

    /**
     * Inicializacao -> "=" [VALOR] | epsilon
     */
    private NoArvore parseInicializacao() throws ErroSintatico {
        NoArvore noInit = new NoArvore("Inicializacao");
        if (tipoAtualEh("ATRIBUICAO")) {
            ReconhecedorAFD.EntradaTabelaSimbolos atrib = atual();
            posicao++;
            noInit.addFilho(new NoArvore("[ATRIBUICAO]", atrib));

            ReconhecedorAFD.EntradaTabelaSimbolos valor = atual();
            if (valor == null) {
                throw new ErroSintatico("Fim inesperado da entrada; esperado valor apos '='.");
            }
            if (!VALORES_VALIDOS.contains(valor.getTipo())) {
                throw new ErroSintatico(descreverErro(valor, "esperado INTEIRO, FRACIONARIO ou NOMEVARIAVEL apos '='"));
            }
            posicao++;
            noInit.addFilho(new NoArvore("[VALOR]", valor));
        } else {
            noInit.addFilho(new NoArvore("epsilon"));
        }
        return noInit;
    }

    public static void validar(List<ReconhecedorAFD.EntradaTabelaSimbolos> tabela) {
        AnalisadorSintatico parser = new AnalisadorSintatico(tabela);
        try {
            NoArvore raiz = parser.parsePrograma();
            System.out.println("Analise sintatica: OK.");
            System.out.println("\nArvore sintatica:");
            raiz.imprimir();
        } catch (ErroSintatico e) {
            System.out.println("Analise sintatica: FALHOU");
            System.out.println(e.getMessage());
        }
    }

    public static void main(String[] args) {
        ReconhecedorAFD afd = new ReconhecedorAFD();
        String caminhoConfig = "AFD_config.txt";
        String caminhoEntrada = "input.c";

        try {
            afd.carregarConfiguracao(caminhoConfig);
            afd.processarArquivo(caminhoEntrada);
            System.out.println();
            validar(afd.getTabelaSimbolos());
        } catch (java.io.IOException e) {
            System.out.println("Erro ao ler arquivo: " + e.getMessage());
        }
    }
}