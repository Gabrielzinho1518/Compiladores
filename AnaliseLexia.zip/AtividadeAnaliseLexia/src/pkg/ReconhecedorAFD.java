package pkg;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Reconhecedor de tokens baseado em Automato Finito Deterministico (AFD).
 *
 * Le a configuracao do AFD (estados, simbolos, estados finais e regras de
 * transicao) a partir de um arquivo de texto, e reconhece termos como:
 *   - Numeros inteiros            (ex: 5, 567)
 *   - Numeros fracionarios/reais  (ex: 3.14)
 *   - Numeros negativos           (ex: -8, -12.5)
 *   - Variaveis / identificadores (ex: nome, var1, X)
 *
 * Formato do arquivo de configuracao (configAFD.txt):
 *   Linha 1: lista de estados, separados por espaco (o primeiro e o inicial)
 *   Linha 2: lista de simbolos do alfabeto, separados por espaco
 *   Linha 3: lista de estados finais no formato estado:TIPO, separados por espaco
 *   Linhas seguintes: regras de transicao no formato estadoAtual:simbolo:estadoDestino
 */
public class ReconhecedorAFD {

    private List<String> estados = new ArrayList<>();
    private List<String> simbolos = new ArrayList<>();
    private List<String> estadosFinais = new ArrayList<>();
    private List<String> regrasTransicao = new ArrayList<>();
    private String estadoInicial;

    /**
     * Carrega a configuracao do AFD a partir do arquivo indicado.
     */
    public void carregarConfiguracao(String caminho) throws IOException {
        try (BufferedReader config = new BufferedReader(new FileReader(caminho))) {

            // Linha 1: estados
            String linhaEstados = config.readLine();
            for (String e : linhaEstados.trim().split(" ")) {
                estados.add(e);
            }
            estadoInicial = estados.get(0);

            // Linha 2: simbolos
            String linhaSimbolos = config.readLine();
            for (String s : linhaSimbolos.trim().split(" ")) {
                simbolos.add(s);
            }

            // Linha 3: estados finais
            String linhaFinais = config.readLine();
            for (String f : linhaFinais.trim().split(" ")) {
                estadosFinais.add(f);
            }

            // Linhas seguintes: regras de transicao
            String linha = config.readLine();
            while (linha != null) {
                if (!linha.trim().isEmpty()) {
                    String[] regras = linha.trim().split(" ");
                    for (String r : regras) {
                        regrasTransicao.add(r);
                    }
                }
                linha = config.readLine();
            }
        }
    }

    /**
     * Tenta reconhecer o termo informado, percorrendo o AFD simbolo a simbolo.
     * Retorna "termo:TIPO" se aceito por um estado final, ou uma mensagem de
     * erro caso o termo nao seja reconhecido.
     */
    public String reconheceTermo(String termo) {
        String estadoAtual = estadoInicial; // reinicia o AFD a cada novo termo
        int numCaracteres = termo.length();

        for (int i = 0; i < numCaracteres; i++) {
            String caractereAtual = String.valueOf(termo.charAt(i));

            if (!simbolos.contains(caractereAtual)) {
                return "Simbolo nao reconhecido: '" + caractereAtual + "' em \"" + termo + "\"";
            }

            // procura a transicao para o par (estadoAtual, caractereAtual)
            String padrao = estadoAtual + ":" + caractereAtual;
            boolean transicaoEncontrada = false;

            for (String regra : regrasTransicao) {
                if (regra.startsWith(padrao + ":")) {
                    String[] reg = regra.split(":"); // estadoAtual:simbolo:estadoDestino
                    estadoAtual = reg[2];
                    transicaoEncontrada = true;
                    break;
                }
            }

            if (!transicaoEncontrada) {
                return "Termo rejeitado (sem transicao valida): \"" + termo + "\"";
            }
        }

        // verifica se o estado atual (final da leitura) e um estado final
        for (String f : estadosFinais) {
            if (f.startsWith(estadoAtual + ":")) {
                String tipo = f.split(":")[1];
                return termo + ":" + tipo;
            }
        }

        return "Termo rejeitado (nao terminou em estado final): \"" + termo + "\"";
    }

    public static void main(String[] args) {
        ReconhecedorAFD afd = new ReconhecedorAFD();

        String caminhoConfig = "src/pkg/configAFD.txt";
        String caminhoNumeros = "src/pkg/numeros.txt";

        try {
            afd.carregarConfiguracao(caminhoConfig);

            try (BufferedReader arquivo = new BufferedReader(new FileReader(caminhoNumeros))) {
                String linha;
                while ((linha = arquivo.readLine()) != null) {
                    linha = linha.trim();
                    if (!linha.isEmpty()) {
                        System.out.println(afd.reconheceTermo(linha));
                    }
                }
            }

        } catch (IOException e) {
            System.out.println("Erro ao ler arquivo: " + e.getMessage());
        }
    }
}